## Minesweeper

Minesweeper game written with React

Play it [here](https://oleksandryehorov.github.io/minesweeper)!

![Screenshot](docs/images/screenshot.png)

![test coverage](https://img.shields.io/codecov/c/github/OleksandrYehorov/minesweeper/master?style=flat-square)
