export const now = (): number => new Date().getTime();
